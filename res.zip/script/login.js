      function login(showhide){
        if(showhide == "show"){
          document.getElementById('popupbox').style.visibility="visible";
        }else if(showhide == "hide"){
          document.getElementById('popupbox').style.visibility="hidden"; 
        }
      }